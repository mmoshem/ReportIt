package com.example.reportit;

import android.os.Bundle;
import android.util.Log;

import androidx.fragment.app.FragmentActivity;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import java.util.ArrayList;
import java.util.List;

public class ReportsMapActivity extends FragmentActivity implements OnMapReadyCallback {
    private GoogleMap mMap;
    private FirebaseFirestore db;
    private List<Report> reportList; // Declare reportList

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports_map);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        db = FirebaseFirestore.getInstance();
        reportList = new ArrayList<>(); // Initialize reportList
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        loadReportsOnMap();
    }

    private void loadReportsOnMap() {
        String userEmail = FirebaseAuth.getInstance().getCurrentUser().getEmail(); // Get the logged-in user's email

        db.collection("reports")
                .whereEqualTo("reporterEmail", userEmail) // Filter reports by email
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    reportList.clear();
                    mMap.clear(); // Clear old markers before adding new ones

                    LatLngBounds.Builder boundsBuilder = new LatLngBounds.Builder();
                    LatLng singleLocation = null; // Store single location for zooming

                    for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        Report report = document.toObject(Report.class);
                        reportList.add(report);

                        LatLng location = new LatLng(report.getLatitude(), report.getLongitude());
                        mMap.addMarker(new MarkerOptions().position(location).title(report.getCategory()));

                        boundsBuilder.include(location); // Always include location in bounds
                        if (reportList.size() == 1) {
                            singleLocation = location; // Store the location for later zooming
                        }
                    }

                    if (!reportList.isEmpty()) {
                        if (reportList.size() == 1 && singleLocation != null) {
                            // If only one report, zoom to it with a moderate level
                            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(singleLocation, 15));
                        } else {
                            // If multiple reports, adjust zoom dynamically to show all
                            int padding = 100; // Padding around markers
                            mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(boundsBuilder.build(), padding));
                        }
                    } else {
                        // If no reports, move to a general location
                        LatLng defaultLocation = new LatLng(32.0853, 34.7818); // Example: Tel Aviv
                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, 12));
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e("Firestore", "Error loading user reports: ", e);
                });
    }




}
