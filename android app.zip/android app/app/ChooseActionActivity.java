package com.example.reportit;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;

public class ChooseActionActivity extends AppCompatActivity {
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_action);

        auth = FirebaseAuth.getInstance();

        // Check if user is logged in; if not, send them to LoginActivity
        if (auth.getCurrentUser() == null) {
            redirectToLogin();
            return; // Prevent the rest of onCreate from running
        }

        findViewById(R.id.add_report_button).setOnClickListener(v ->
                startActivity(new Intent(this, AddReportActivity.class)));


        findViewById(R.id.view_user_reports_button).setOnClickListener(v ->
                startActivity(new Intent(this, UserReportsActivity.class)));

        Button logoutButton = findViewById(R.id.logout_button);
        logoutButton.setOnClickListener(v -> signOut());
    }

    // Redirect users to login if they are not authenticated
    private void redirectToLogin() {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }


    private void signOut() {
        auth.signOut();

        // Ensure user session is completely cleared
        new android.os.Handler().postDelayed(() -> {
            Intent intent = new Intent(ChooseActionActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }, 500); // Small delay to allow Firebase state update
    }


}
