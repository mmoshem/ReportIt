package com.example.reportit;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.reportit.R;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.CameraUpdateFactory;


public class SelectLocationActivity extends AppCompatActivity implements GoogleMap.OnMapClickListener {
    private GoogleMap mMap;
    private double selectedLat, selectedLng;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_location);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(googleMap -> {
            mMap = googleMap;
            mMap.setOnMapClickListener(this);

            // ✅ Set the map view to Israel (Default: Tel Aviv)
            LatLng israel = new LatLng(31.0461, 34.8516); // Center of Israel
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(israel, 8)); // Zoom level 8 is good for a country-wide view
        });
    }

    @Override
    public void onMapClick(LatLng point) {
        mMap.clear();  // Remove previous markers
        mMap.addMarker(new MarkerOptions().position(point).title("Selected Location"));

        selectedLat = point.latitude;
        selectedLng = point.longitude;

        // Return result to AddReportActivity
        Intent resultIntent = new Intent();
        resultIntent.putExtra("latitude", selectedLat);
        resultIntent.putExtra("longitude", selectedLng);
        setResult(RESULT_OK, resultIntent);
        finish();
    }
}
