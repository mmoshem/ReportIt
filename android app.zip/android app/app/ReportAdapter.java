package com.example.reportit;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;

public class ReportAdapter extends RecyclerView.Adapter<ReportAdapter.ViewHolder> {
    private Context context;
    private List<Report> reports;

    public ReportAdapter(Context context, List<Report> reports) {
        this.context = context;
        this.reports = reports;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_report, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Report report = reports.get(position);
        holder.txtDescription.setText(report.getDescription());
        holder.txtCategory.setText(report.getCategory());
        holder.txtStatus.setText(report.getStatus());

        // ✅ Change color based on status
        switch (report.getStatus().toLowerCase()) {
            case "processing":
                holder.txtStatus.setTextColor(Color.parseColor("#FFA500")); // Orange
                break;
            case "resolved":
                holder.txtStatus.setTextColor(Color.parseColor("#008000")); // Green
                break;
            case "pending":
                holder.txtStatus.setTextColor(Color.parseColor("#FF0000")); // Red
                break;
            default:
                holder.txtStatus.setTextColor(Color.BLACK); // Default color
                break;
        }



        // ✅ Check if photoUrl is empty or null
        if (report.getPhotoUrl() != null && !report.getPhotoUrl().isEmpty()) {
            Glide.with(context)
                    .load(report.getPhotoUrl())
                    .placeholder(R.drawable.placeholder_image)  // ✅ Show while loading
                    .error(R.drawable.error_image)  // ✅ Show if error
                    .into(holder.imgReportPhoto);
        } else {
            holder.imgReportPhoto.setImageResource(R.drawable.placeholder_image);  // ✅ Default image if no URL
        }
    }

    @Override
    public int getItemCount() {
        return reports.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtDescription, txtCategory, txtStatus;
        ImageView imgReportPhoto;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtDescription = itemView.findViewById(R.id.txt_description);
            txtCategory = itemView.findViewById(R.id.txt_category);
            txtStatus = itemView.findViewById(R.id.txt_status);
            imgReportPhoto = itemView.findViewById(R.id.img_report_photo);
        }
    }
}