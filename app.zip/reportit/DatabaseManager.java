package com.example.reportit;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class DatabaseManager {
    private FirebaseFirestore db;

    public DatabaseManager() {
        db = FirebaseFirestore.getInstance();
    }

    public void getAllReports(Consumer<List<Report>> callback) {
        db.collection("reports").get().addOnSuccessListener(queryDocumentSnapshots -> {
            List<Report> reportList = new ArrayList<>();
            for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                reportList.add(document.toObject(Report.class));
            }
            callback.accept(reportList);
        });
    }

}
