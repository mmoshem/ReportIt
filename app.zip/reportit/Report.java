package com.example.reportit;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.PropertyName;
import com.google.firebase.firestore.ServerTimestamp;
import com.google.firebase.Timestamp;

import java.util.Map;

public class Report {
    private String id;
    private String status;
    private String address;
    private String category;
    private String description;
    private String handlerEmail;
    private double latitude;
    private double longitude;
    private String photoUrl;
    private String reporterEmail;

    private Timestamp submissionDate;

    // Empty constructor for Firestore
    public Report() {
    }

    public Report(String id, String status, String address, String category, String description,
                  String handlerEmail, double latitude, double longitude, String photoUrl,
                  String reporterEmail, Timestamp submissionDate) {
        this.id = id;
        this.status = status;
        this.address = address;
        this.category = category;
        this.description = description;
        this.handlerEmail = handlerEmail;
        this.latitude = latitude;
        this.longitude = longitude;
        this.photoUrl = photoUrl;
        this.reporterEmail = reporterEmail;
        this.submissionDate = submissionDate;
    }

    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getHandlerEmail() { return handlerEmail; }
    public void setHandlerEmail(String handlerEmail) { this.handlerEmail = handlerEmail; }

    public double getLatitude() { return latitude; }
    public void setLatitude(double latitude) { this.latitude = latitude; }

    public double getLongitude() { return longitude; }
    public void setLongitude(double longitude) { this.longitude = longitude; }

    public String getPhotoUrl() { return photoUrl; }
    public void setPhotoUrl(String photoUrl) { this.photoUrl = photoUrl; }

    public String getReporterEmail() { return reporterEmail; }
    public void setReporterEmail(String reporterEmail) { this.reporterEmail = reporterEmail; }

    @PropertyName("submissionDate") // Ensures correct Firestore mapping
    public Timestamp getSubmissionDate() { return submissionDate; }

    @PropertyName("submissionDate")
    public void setSubmissionDate(Object submissionDate) {
        if (submissionDate instanceof Timestamp) {
            this.submissionDate = (Timestamp) submissionDate; // ✅ Correct format
        } else if (submissionDate instanceof Map) {
            Map<String, Object> timestampMap = (Map<String, Object>) submissionDate;
            long seconds = (long) timestampMap.get("_seconds");
            int nanoseconds = ((Long) timestampMap.get("_nanoseconds")).intValue();
            this.submissionDate = new Timestamp(seconds, nanoseconds); // ✅ Convert HashMap to Timestamp
        } else {
            this.submissionDate = null; // Fallback case
        }
    }
}
