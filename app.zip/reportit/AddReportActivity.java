package com.example.reportit;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Date;

public class AddReportActivity extends AppCompatActivity {
    private static final int PICK_IMAGE_REQUEST = 1;
    private EditText hazardDescription, hazardCategory, hazardAddress;
    private ImageView selectedImage;
    private Uri imageUri;
    private FirebaseFirestore db;
    private FusedLocationProviderClient fusedLocationClient;
    private static final int LOCATION_PICKER_REQUEST = 2;
    private double selectedLatitude = 0;
    private double selectedLongitude = 0;


    // check
    // Request location permission launcher
    private final ActivityResultLauncher<String> requestLocationPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    fetchCurrentLocation(); // Permission granted, get location
                } else {
                    Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_report);

        hazardDescription = findViewById(R.id.hazard_description);
        hazardCategory = findViewById(R.id.hazard_category);
        hazardAddress = findViewById(R.id.hazard_address);
        selectedImage = findViewById(R.id.selected_image);
        db = FirebaseFirestore.getInstance();
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);



        Button selectLocationButton = findViewById(R.id.select_location_button);
        selectLocationButton.setOnClickListener(v -> openMapSelection());

        Button selectImageButton = findViewById(R.id.select_image_button);
        Button currentLocationButton = findViewById(R.id.current_location_button);
        Button submitButton = findViewById(R.id.submit_report_button);

        submitButton.setOnClickListener(v -> submitReport());
        selectImageButton.setOnClickListener(v -> openImageChooser());
        currentLocationButton.setOnClickListener(v -> requestLocationPermission());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            Log.d("ImageSelection", "Image selected: " + imageUri.toString());

            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
                selectedImage.setImageBitmap(bitmap);
                selectedImage.setVisibility(View.VISIBLE);
            } catch (IOException e) {
                Log.e("ImageSelection", "Error loading image", e);
                e.printStackTrace();
            }
        } else if (requestCode == LOCATION_PICKER_REQUEST && resultCode == RESULT_OK && data != null) {
            // ✅ Capture map-selected location
            selectedLatitude = data.getDoubleExtra("latitude", 0);
            selectedLongitude = data.getDoubleExtra("longitude", 0);

            Log.d("LocationSelection", "User selected location: " + selectedLatitude + ", " + selectedLongitude);

            // ✅ Call Google API to get address
            getAddressFromGoogleMaps(selectedLatitude, selectedLongitude);
        }
    }








    private void openMapSelection() {
        Intent intent = new Intent(this, SelectLocationActivity.class);
        startActivityForResult(intent, LOCATION_PICKER_REQUEST);
    }

    private void requestLocationPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
            // The user denied permission before, show why we need it
            new AlertDialog.Builder(this)
                    .setTitle("Location Permission Required")
                    .setMessage("This app requires location access to detect your current position.")
                    .setPositiveButton("OK", (dialog, which) ->
                            ActivityCompat.requestPermissions(this, new String[]{
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION
                            }, 100))
                    .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                    .show();
        } else {
            // Directly request permission
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            }, 100);
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                fetchCurrentLocation();  // ✅ Permission granted
            } else if (!ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                // The user selected "Don't Ask Again", show manual settings dialog
                showPermissionSettingsDialog();
            } else {
                Toast.makeText(this, "Location permission denied. Enable it in settings.", Toast.LENGTH_LONG).show();
            }
        }
    }

    // Prompt the user to enable location manually
    private void showPermissionSettingsDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Permission Required")
                .setMessage("Location permission is permanently denied. Enable it in settings.")
                .setPositiveButton("Go to Settings", (dialog, which) -> {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    Uri uri = Uri.fromParts("package", getPackageName(), null);
                    intent.setData(uri);
                    startActivity(intent);
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .show();
    }




    private void fetchCurrentLocation() {
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        boolean isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);

        if (!isGPSEnabled) {
            Toast.makeText(this, "Please enable GPS", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)); // Open GPS settings
            return;
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestLocationPermission();
            return;
        }

        fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
            if (location != null) {
                selectedLatitude = location.getLatitude();
                selectedLongitude = location.getLongitude();

                Log.d("GPSLocation", "Fetched location: " + selectedLatitude + ", " + selectedLongitude);

                // ✅ Update address field dynamically
                getAddressFromGoogleMaps(selectedLatitude, selectedLongitude);
            } else {
                Toast.makeText(this, "Failed to get location. Try again.", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(e -> {
            Toast.makeText(this, "Error getting location: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            Log.e("LocationError", "Error: ", e);
        });
    }



    private void getAddressFromGoogleMaps(double latitude, double longitude) {
        String apiKey = getString(R.string.my_map_api_key);
        String url = "https://maps.googleapis.com/maps/api/geocode/json?latlng=" + latitude + "," + longitude + "&key=" + apiKey;

        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest request = new StringRequest(Request.Method.GET, url, response -> {
            try {
                Log.d("GoogleMapsAPI", "API Response: " + response);

                JSONObject jsonObject = new JSONObject(response);
                JSONArray results = jsonObject.getJSONArray("results");

                if (results.length() > 0) {
                    String bestAddress = null;

                    for (int i = 0; i < results.length(); i++) {
                        JSONObject result = results.getJSONObject(i);
                        String address = result.getString("formatted_address");

                        // ✅ Ignore Plus Codes (short codes like "2PHQ+5H")
                        if (!address.contains("+")) {
                            bestAddress = address;
                            break;  // Use the first valid address found
                        }
                    }

                    if (bestAddress != null) {
                        hazardAddress.setText(bestAddress);  // ✅ Update UI with detailed address
                        Log.d("GoogleMapsAPI", "Selected Address: " + bestAddress);
                    } else {
                        hazardAddress.setText("Unknown Location");
                        Log.e("GoogleMapsAPI", "No valid address found");
                    }
                } else {
                    hazardAddress.setText("Unknown Location");
                    Log.e("GoogleMapsAPI", "No results found");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }, error -> {
            Log.e("GoogleMapsAPI", "Error fetching address: " + error.toString());
        });

        queue.add(request);
    }












    // Open image gallery
    private void openImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    // Submit the report
    private void submitReport() {
        if (imageUri != null) {
            uploadImageToFirebase(imageUri);
        } else {
            saveReportToFirestore(""); // No image, save report with an empty image URL
        }
    }

    private void uploadImageToFirebase(Uri imageUri) {
        if (imageUri == null) {
            Log.e("FirebaseStorage", "Image URI is null! Cannot upload.");
            Toast.makeText(this, "No image selected!", Toast.LENGTH_SHORT).show();
            return;
        }

        Log.d("FirebaseStorage", "Uploading image: " + imageUri.toString()); // ✅ Debug log

        // Reference to Firebase Storage in 'hazard_images' folder
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageRef = storage.getReference("hazard_images/" + System.currentTimeMillis() + ".jpg");

        storageRef.putFile(imageUri)
                .addOnSuccessListener(taskSnapshot -> storageRef.getDownloadUrl().addOnSuccessListener(uri -> {
                    String imageUrl = uri.toString();
                    Log.d("FirebaseStorage", "Image uploaded successfully: " + imageUrl); // ✅ Debug log
                    saveReportToFirestore(imageUrl); // Save report with correct image URL
                }))
                .addOnFailureListener(e -> {
                    Log.e("FirebaseStorage", "Image upload failed", e);
                    Toast.makeText(this, "Image Upload Failed", Toast.LENGTH_SHORT).show();
                });
    }



    private void saveReportToFirestore(String imageUrl) {
        FirebaseAuth auth = FirebaseAuth.getInstance();
        FirebaseUser user = auth.getCurrentUser();

        if (user == null) {
            Toast.makeText(this, "You need to log in to submit a report", Toast.LENGTH_SHORT).show();
            return;
        }

        String userEmail = user.getEmail();
        Log.d("FirestoreDebug", "Using reporter email: " + userEmail);
        Log.d("FirestoreDebug", "Latitude: " + selectedLatitude + ", Longitude: " + selectedLongitude);  // Debugging

        Report report = new Report(
                "",  // Firestore ID (updated later)
                "Pending",
                hazardAddress.getText().toString(),
                hazardCategory.getText().toString(),
                hazardDescription.getText().toString(),
                "",  // Handler Email
                selectedLatitude,  // ✅ Correct Latitude
                selectedLongitude,  // ✅ Correct Longitude
                imageUrl,  // ✅ Image URL
                userEmail,  // ✅ User Email
                Timestamp.now()
        );

        db.collection("reports").add(report)
                .addOnSuccessListener(documentReference -> {
                    documentReference.update("id", documentReference.getId())
                            .addOnSuccessListener(aVoid ->
                                    Toast.makeText(this, "Report Submitted Successfully", Toast.LENGTH_SHORT).show()
                            )
                            .addOnFailureListener(e ->
                                    Toast.makeText(this, "Failed to update report ID", Toast.LENGTH_SHORT).show()
                            );

                    finish();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed to submit report", Toast.LENGTH_SHORT).show()
                );
    }






}
